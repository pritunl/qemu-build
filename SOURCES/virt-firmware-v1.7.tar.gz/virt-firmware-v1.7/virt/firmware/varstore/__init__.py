""" efi varstore parsers """
__all__ = [ "edk2", "linux", "aws" ]
